export const dummyGatewayId = "saleor.io.dummy-payment-app";
export type DummyGatewayId = typeof dummyGatewayId;
